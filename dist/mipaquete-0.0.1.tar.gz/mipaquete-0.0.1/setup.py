from setuptools import setup

setup(
    author='Gonzalo',
    author_email='gonzaloe281@gmail.com',
    description='prueba de creacion de paquete redistribuible',
    version='0.0.1',
    name='mipaquete',
    packages=['matematica']
)