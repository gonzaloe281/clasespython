var_de_operacion = 225

def sumar(a,b):
    return a+b


def restar(a,b):
    return a-b

class Cuadrado:
    def __init__(self, lado):
        self.lado = lado
        
    def perimetro(self):
        return self.lado * 4
    


# print(2+2) #no se usa en modulos esta logica
# variable = 2+2
# print(variable)